"""
Core functionality for adAI library
"""


def hello():
    """Example function to get started"""
    return "Hello from adAI!"
