"""
MLP module for adAI
"""

import numpy as np
from typing import List, Optional, Dict
from .perceptron import (
    generate_and_data,
    generate_or_data,
    generate_nor_data,
    generate_nand_data,
    generate_not_data,
)


class MLP:
    """A multi-layer perceptron network."""

    def __init__(
        self,
        input_size: int,
        hidden_layers: Optional[List[int]] = None,
        output_size: int = 1,
        learning_rate: float = 0.01,
        epochs: int = 100,
        activation: str = "relu",
        output_activation: str = "sigmoid",
        l2: float = 0.0,
        dropout: float = 0.0,
    ):
        """
        Initialize an MLP with dynamically built hidden layers.

        Args:
            activation: Activation for hidden layers ("relu", "tanh", "sigmoid").
            output_activation: Activation for the output layer
                ("sigmoid", "relu", or "linear"). Use "relu" or "linear"
                for regression tasks where targets can exceed [0, 1].
        """
        self.input_size = input_size
        self.hidden_layers = hidden_layers or []
        self.output_size = output_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.activation = activation
        self.output_activation = output_activation
        self.l2 = l2
        self.dropout = dropout

        if self.dropout < 0 or self.dropout >= 1:
            raise ValueError("dropout must be in [0.0, 1.0)")

        self.layer_sizes = [self.input_size] + self.hidden_layers + [self.output_size]
        self.layers: List[Dict[str, np.ndarray]] = []
        for in_size, out_size in zip(self.layer_sizes[:-1], self.layer_sizes[1:]):
            self.layers.append({
                "weights": np.random.randn(in_size, out_size).astype(np.float32) * 0.01,
                "bias": np.zeros(out_size, dtype=np.float32),
            })

        self.loss_history: List[float] = []

    def summary(self):
        """Print model summary."""
        total_params = sum(layer["weights"].size + layer["bias"].size for layer in self.layers)
        print("MLP Summary:")
        print(f"  Input size:          {self.input_size}")
        print(f"  Hidden layers:       {self.hidden_layers}")
        print(f"  Output size:         {self.output_size}")
        print(f"  Activation:          {self.activation}")
        print(f"  Output activation:   {self.output_activation}")
        print(f"  Layers:              {self.layer_sizes}")
        print(f"  Dropout:             {self.dropout}")
        print(f"  L2 regularizer:      {self.l2}")
        print(f"  Total params:        {total_params}")

    def _activation(self, x: np.ndarray) -> np.ndarray:
        if self.activation == "relu":
            return np.maximum(0, x)
        elif self.activation == "tanh":
            return np.tanh(x)
        elif self.activation == "sigmoid":
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))
        else:
            return x

    def _activation_derivative(self, activated: np.ndarray) -> np.ndarray:
        if self.activation == "relu":
            return (activated > 0).astype(np.float32)
        elif self.activation == "tanh":
            return 1 - activated ** 2
        elif self.activation == "sigmoid":
            return activated * (1 - activated)
        else:
            return np.ones_like(activated)

    def _output_activation(self, x: np.ndarray) -> np.ndarray:
        if self.output_activation == "relu":
            return np.maximum(0, x)
        elif self.output_activation == "linear":
            return x
        else:  # sigmoid (default)
            return 1 / (1 + np.exp(-np.clip(x, -500, 500)))

    def _output_activation_derivative(self, activated: np.ndarray) -> np.ndarray:
        if self.output_activation == "relu":
            return (activated > 0).astype(np.float32)
        elif self.output_activation == "linear":
            return np.ones_like(activated)
        else:  # sigmoid
            return activated * (1 - activated)

    def forward(self, X: np.ndarray, training: bool = False):
        activations = [X]
        pre_activations = []
        dropout_masks: List[Optional[np.ndarray]] = []

        for index, layer in enumerate(self.layers):
            z = np.dot(activations[-1], layer["weights"]) + layer["bias"]
            pre_activations.append(z)

            if index < len(self.layers) - 1:
                a = self._activation(z)
                mask = None
                if training and self.dropout > 0:
                    mask = (np.random.rand(*a.shape) >= self.dropout).astype(np.float32) / (1 - self.dropout)
                    a = a * mask
                activations.append(a)
                dropout_masks.append(mask)
            else:
                a = self._output_activation(z)
                activations.append(a)
                dropout_masks.append(None)

        return activations, pre_activations, dropout_masks

    def train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        X_val: Optional[np.ndarray] = None,
        y_val: Optional[np.ndarray] = None,
        batch_size: Optional[int] = None,
        early_stopping: bool = False,
        patience: int = 10,
        verbose: bool = False,
    ) -> dict:
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.float32)
        if X_val is not None:
            X_val = np.asarray(X_val, dtype=np.float32)
        if y_val is not None:
            y_val = np.asarray(y_val, dtype=np.float32)

        if batch_size is None:
            batch_size = len(X)

        val_loss_history: List[float] = []
        best_val_loss = float("inf")
        patience_counter = 0

        for epoch in range(self.epochs):
            indices = np.random.permutation(len(X))
            epoch_loss = 0.0

            for start in range(0, len(X), batch_size):
                batch_idx = indices[start:start + batch_size]
                X_batch = X[batch_idx]
                y_batch = y[batch_idx]

                activations, _, dropout_masks = self.forward(X_batch, training=True)
                output = activations[-1]

                if output.ndim == 2 and y_batch.ndim == 1:
                    y_batch = y_batch.reshape(-1, 1)

                error = y_batch - output
                batch_loss = np.mean(error**2)
                epoch_loss += batch_loss

                delta = error * self._output_activation_derivative(output)

                for layer_index in reversed(range(len(self.layers))):
                    a_prev = activations[layer_index]
                    w = self.layers[layer_index]["weights"]
                    grad_w = np.dot(a_prev.T, delta) / len(X_batch)
                    grad_b = np.mean(delta, axis=0)

                    if self.l2 > 0:
                        grad_w += self.l2 * w

                    self.layers[layer_index]["weights"] += self.learning_rate * grad_w
                    self.layers[layer_index]["bias"] += self.learning_rate * grad_b

                    if layer_index > 0:
                        delta = np.dot(delta, w.T)
                        mask = dropout_masks[layer_index - 1]
                        if mask is not None:
                            delta *= mask
                        delta = delta * self._activation_derivative(activations[layer_index])

            epoch_loss /= max(1, len(X) // batch_size)
            self.loss_history.append(epoch_loss)

            if X_val is not None and y_val is not None:
                val_output = self.predict(X_val)
                val_error = y_val - val_output
                val_loss = np.mean(val_error**2)
                val_loss_history.append(val_loss)

                if early_stopping:
                    if val_loss < best_val_loss:
                        best_val_loss = val_loss
                        patience_counter = 0
                    else:
                        patience_counter += 1
                        if patience_counter >= patience:
                            if verbose:
                                print(f"Early stopping at epoch {epoch + 1}")
                            break

            if verbose and (epoch + 1) % max(1, self.epochs // 10) == 0:
                msg = f"Epoch {epoch + 1}/{self.epochs}, Loss: {epoch_loss:.6f}"
                if X_val is not None:
                    msg += f", Val Loss: {val_loss:.6f}"
                print(msg)

        return {
            "loss_history": self.loss_history,
            "val_loss_history": val_loss_history if val_loss_history else None,
            "final_loss": self.loss_history[-1] if self.loss_history else None,
            "final_val_loss": val_loss_history[-1] if val_loss_history else None,
            "epochs_trained": len(self.loss_history),
        }

    def print_training_summary(self, history: dict):
        print(f"\nTraining completed in {history['epochs_trained']} epochs")
        print(f"  Final train loss: {history['final_loss']:.6f}")
        if history["final_val_loss"]:
            print(f"  Final val loss:   {history['final_val_loss']:.6f}")

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=np.float32)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        activations, _, _ = self.forward(X, training=False)
        output = activations[-1]
        if self.output_size == 1:
            return np.squeeze(output, axis=-1)
        return output

    def evaluate(self, X: np.ndarray, y: np.ndarray) -> dict:
        predictions = self.predict(X)
        if predictions.ndim > 1 and predictions.shape[1] == 1:
            predictions = np.squeeze(predictions, axis=-1)
        y_flat = np.squeeze(y)
        mse = np.mean((y_flat - predictions) ** 2)
        mae = np.mean(np.abs(y_flat - predictions))
        binary_predictions = (predictions > 0.5).astype(int)
        accuracy = np.mean(binary_predictions == y_flat) if np.all((y_flat == 0) | (y_flat == 1)) else None
        return {
            "mse": mse,
            "mae": mae,
            "rmse": np.sqrt(mse),
            "accuracy": accuracy,
        }

    def print_metrics(self, metrics: dict):
        print(f"\nTest Metrics:")
        print(f"  MSE:      {metrics['mse']:.6f}")
        print(f"  MAE:      {metrics['mae']:.6f}")
        print(f"  RMSE:     {metrics['rmse']:.6f}")
        if metrics["accuracy"]:
            print(f"  Accuracy: {metrics['accuracy']:.2%}")

    def save(self, path: str):
        payload = {
            "input_size": self.input_size,
            "hidden_layers": np.array(self.hidden_layers, dtype=np.int32),
            "output_size": self.output_size,
            "learning_rate": self.learning_rate,
            "epochs": self.epochs,
            "activation": self.activation,
            "output_activation": self.output_activation,
            "l2": self.l2,
            "dropout": self.dropout,
            "n_layers": len(self.layers),
            "loss_history": np.array(self.loss_history, dtype=np.float64),
        }
        for index, layer in enumerate(self.layers):
            payload[f"weights_{index}"] = layer["weights"]
            payload[f"bias_{index}"] = layer["bias"]
        np.savez_compressed(path, **payload)

    @classmethod
    def load(cls, path: str) -> "MLP":
        data = np.load(path, allow_pickle=True)
        hidden_layers = data["hidden_layers"].tolist()
        # Backward compatibility: default to "sigmoid" if not saved
        out_act = str(data["output_activation"]) if "output_activation" in data else "sigmoid"
        mlp = cls(
            input_size=int(data["input_size"]),
            hidden_layers=hidden_layers,
            output_size=int(data["output_size"]),
            learning_rate=float(data["learning_rate"]),
            epochs=int(data["epochs"]),
            activation=str(data["activation"]),
            output_activation=out_act,
            l2=float(data["l2"]),
            dropout=float(data["dropout"]),
        )
        for index in range(int(data["n_layers"])):
            mlp.layers[index]["weights"] = data[f"weights_{index}"]
            mlp.layers[index]["bias"] = data[f"bias_{index}"]
        mlp.loss_history = data["loss_history"].tolist()
        return mlp

    def generate_xor_data(self):
        return generate_xor_data()

    def generate_xnor_data(self):
        return generate_xnor_data()

    def generate_not_data(self):
        return generate_not_data()

    def generate_or_data(self):
        return generate_or_data()

    def generate_nor_data(self):
        return generate_nor_data()

    def generate_and_data(self):
        return generate_and_data()

    def generate_nand_data(self):
        return generate_nand_data()


def generate_xor_data():
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=np.float32)
    y = np.array([0, 1, 1, 0], dtype=float)
    return X, y


def generate_xnor_data():
    X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=np.float32)
    y = np.array([1, 0, 0, 1], dtype=float)
    return X, y


def GenerateXORMlp(
    learning_rate: float = 0.1,
    epochs: int = 1000,
    activation: str = "tanh",
    output_activation: str = "sigmoid",
    l2: float = 0.0,
    dropout: float = 0.0,
) -> MLP:
    """Create a minimal MLP configured for XOR learning."""
    return GenerateMLP(
        input_size=2,
        hidden_layers=[2],
        output_size=1,
        learning_rate=learning_rate,
        epochs=epochs,
        activation=activation,
        output_activation=output_activation,
        l2=l2,
        dropout=dropout,
    )


def GenerateMLP(
    input_size: int,
    hidden_layers: Optional[List[int]] = None,
    output_size: int = 1,
    learning_rate: float = 0.01,
    epochs: int = 100,
    activation: str = "relu",
    output_activation: str = "sigmoid",
    l2: float = 0.0,
    dropout: float = 0.0,
) -> MLP:
    """
    Automatically generate and initialize an MLP.

    Args:
        output_activation: Activation for the output layer.
            "sigmoid" for classification, "relu" or "linear" for regression.
    """
    return MLP(
        input_size=input_size,
        hidden_layers=hidden_layers,
        output_size=output_size,
        learning_rate=learning_rate,
        epochs=epochs,
        activation=activation,
        output_activation=output_activation,
        l2=l2,
        dropout=dropout,
    )