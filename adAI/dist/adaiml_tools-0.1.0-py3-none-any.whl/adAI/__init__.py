"""
adAI - A Python library for making AI easier
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .perceptron import (
    GeneratePerceptron,
    Perceptron,
    generate_logic_gate_data,
    generate_not_data,
    generate_or_data,
    generate_nor_data,
    generate_and_data,
    generate_nand_data,
)
from .mlp import GenerateMLP, GenerateXORMlp, MLP, generate_xor_data
from .cnn import GenerateCNN, CNN

__all__ = [
    'GeneratePerceptron',
    'Perceptron',
    'generate_logic_gate_data',
    'generate_not_data',
    'generate_or_data',
    'generate_nor_data',
    'generate_and_data',
    'generate_nand_data',
    'GenerateMLP',
    'GenerateXORMlp',
    'MLP',
    'generate_xor_data',
    'GenerateCNN',
    'CNN',
]
